python run.py --gtkwave-fmt vcd 
gtkwave vunit_out/test_output/testbench.top_tb.all_b302af7932a1f1796688691493a082786e50ae39/ghdl/wave.vcd
