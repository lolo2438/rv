##############################################################################
# TRIUMF4 Benchmarks unit test runner
# Original Author : Simon
# Modified by : Alexis
# Date : 2018-12-06
# Adapted from https://github.com/VUnit/vunit/blob/master/examples/vhdl/uart/run.py
##############################################################################
from os.path import join, dirname
from glob import glob
from vunit import VUnit

ui = VUnit.from_argv()

riscv_lib = ui.add_library("riscv")
riscv_lib_src = glob("../src/riscv/*.vhd");
riscv_lib.add_source_files(riscv_lib_src);

tb = ui.add_library("testbench")

datapath_files = glob("../src/datapath/*.vhd")
tb.add_source_files(datapath_files)

alu_files = glob("../src/alu/*.vhd")
tb.add_source_files(alu_files)

decoder_files = glob("../src/decoder/*.vhd")
tb.add_source_files(decoder_files)

data_ram_files = glob("../src/data_ram/*.vhd")
tb.add_source_files(data_ram_files)

sdp_bram_files = glob("../src/sdp_bram/*.vhd")
tb.add_source_files(sdp_bram_files)

branch_unit_files = glob("../src/branch_unit/*.vhd")
tb.add_source_files(branch_unit_files)

other_files = glob("../src/*.vhd")
tb.add_source_files(other_files)

tb_files = {i: tb_file for i, tb_file in enumerate(glob("*.vhd"))}
[print(f'{i} {tb_file}') for i, tb_file in tb_files.items()]

tb_to_run = input('Enter the number of the tb you want to run : ')

tb.add_source_files(tb_files[int(tb_to_run)])


ui.set_compile_option("ghdl.a_flags", ["-frelaxed-rules", "--no-vital-checks"])
ui.set_sim_option("ghdl.elab_flags", ["-fexplicit", "-frelaxed-rules",
             "--no-vital-checks", "--warn-binding", "--mb-comments"])

ui.main()
